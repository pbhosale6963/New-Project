import java.util.Scanner;
public class Q8_ASCII_Value {

	public static void main(String[] args) 
	{
		for (int i=0; i<=255;i++)
		{
			int a = i;
			char c = (char)a;
			System.out.println("ASCII Value of"+" "+a+" "+"is"+" "+c);
		}
		
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Any Number :-");
		
		int b = s.nextInt();
		char n = (char)b;
		
		System.out.println("ASCII Value of "+b+" "+"is"+" "+n);
		s.close();
	}

}
