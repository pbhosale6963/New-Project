
public class Q7_Pattern_5 {

	public static void main(String[] args) 
	{
		int n=8;
		for (int i=1;i<=5;i++)
		{
			for (int s=0;s<=n;s++)
			{
				System.out.print(" ");
			}
			n=n-2;
			for (int j=0;j<=2*i-2;j++)
			{
				
				System.out.print(i);
			}
			System.out.println();
		}
	}
}
