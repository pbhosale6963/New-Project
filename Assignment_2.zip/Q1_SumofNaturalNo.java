
public class Q1_SumofNaturalNo {

	public static void main(String[] args) 
	{
		int sum=0;
		for (int i=1;i<=10;++i)
		{
			sum = sum+i;
		}
		System.out.println("Sum of Natural Numbers"+" "+sum);
		
	}

}
