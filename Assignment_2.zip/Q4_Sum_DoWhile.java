import java.util.*;
public class Q4_Sum_DoWhile {

	public static void main(String[] args) 
	{
		char c;
		Scanner s = new Scanner(System.in);
		do 
		{
		System.out.println("Enter two numbers");		
		int A = s.nextInt();
		int B = s.nextInt();
		
		int sum = A+B;
		System.out.println("Sum of two numbers:-"+" "+sum);
		
		System.out.println("Do you want to perform it again pls press Y or N");
		c = s.next().charAt(0);
		
		if(c=='n'||c=='N') 
		{
			System.out.println("Thank You");
			break;
		}
		}
		while(c=='y'||c=='Y');	
		s.close();

	}

}
