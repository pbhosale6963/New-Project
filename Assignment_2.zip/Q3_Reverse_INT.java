import java.util.Scanner;
public class Q3_Reverse_INT {

	public static void main(String[] args) 
	{
		int a, b;
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter Number");
		a = s.nextInt();
		
		while(a!=0)
		{
			b = a%10;
			System.out.print(b);
			
			a = a/10;
		}
		s.close();
	}
}
