import java.util.Scanner;
public class Q2_Table {

	public static void main(String[] args) 
	{
		int i;
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter Number");
		int a = s.nextInt();

		for (i=1; i<=10;++i)
		{
			System.out.println(a*i);
			s.close();
		}

	}

}
