import java.util.Scanner;
public class Q9_EvenOdd {
	public static void main(String[] args) 
		{
			int x[] = new int [5];
			Scanner s = new Scanner(System.in);
			int counteven=0;
			int countodd=0;
			int A =counteven;
			int B =countodd;
			for (int i=0; i<5 ; i++)
			{
				System.out.println("Enter Number");
				x[i]= s.nextInt();
				if (x[i]%2==0)
					A++;
				else
					B++;
			}
			System.out.println();
			System.out.println("Even Count :-"+" "+A);
			System.out.println("Odd Count :-"+" "+B);		
			s.close();
		}

	}
