import java.util.Scanner;
public class Q6_Fabnocci_Series {

	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Number");
		int n = s.nextInt();
		
		int a = 0, b = 1, sum =0;
		System.out.print(a+" ");
		System.out.print(b+" ");
		
		for (int i=0; i<=n ; i++)
		{
			sum = a+b;
			a=b;
			b=sum;
			System.out.print(sum+" ");
		}
		s.close();
	}
}
