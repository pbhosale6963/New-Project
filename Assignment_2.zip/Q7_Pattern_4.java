
public class Q7_Pattern_4 {

	public static void main(String[] args) 
	{
		int i,s,j,n=8;
		for (i=0;i<5;i++)
		{
			for (s=0;s<=n;s++)
			{
				System.out.print(" ");
			}
			n=n-2;
		
			for (j=0;j<=2*i;j++)
			{
				System.out.print("*");
			}
			System.out.println();

		}

	}

}
