
public class Q5_ArmstrongNo {

	public static void main(String[] args) 
	{
		int a;
		int rem;
		int sum = 0;
		for (int i = 1; i<=500 ; i++)
		{
			a = i;
			while (a!=0)
			{
			rem = a%10;
			sum += Math.pow(rem, 3);
			a =a/10;
			}
			if (sum == i)
			{
				System.out.print(i+" ");
			}
			sum = 0;
		}
	}
}